# forex-faperalta2
